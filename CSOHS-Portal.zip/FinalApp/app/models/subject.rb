class Subject < ActiveRecord::Base
validates :subject_name, presence:true
validates :teacher_id, presence:true
end
