class Student < ActiveRecord::Base
mount_uploader :image, ImageUploader

validates :name, :with => /\A[^0-9`!@#\$%\^&*+_=]+\z/, presence: true
validates :gender, presence: true
validates :birthday, presence: true
validates :age, numerically: {only_integers: true} presence: true
validates :address, presence: true
validates :level, presence: true


end
